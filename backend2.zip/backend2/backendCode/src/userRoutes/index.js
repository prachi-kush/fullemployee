

app.get("/", MiddleService, userService.getUser)

app.post("")