const userService = {
    getUser: function () {
        return "Hello User!!"
    },
    postUser: function () {
        return "Sending data!!"
    }

}

module.exports = userService